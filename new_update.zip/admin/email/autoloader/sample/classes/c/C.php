<?php

class C extends A
{
	public function __construct()
	{
		parent::__construct();
	}

}

// EOF
