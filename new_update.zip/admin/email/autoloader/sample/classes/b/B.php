<?php

class B
{
	public function __construct()
	{
		echo __CLASS__;
	}

}
