








<nav class="sidebar sidebar-offcanvas ml-0 shadow" id="sidebar" style="background-color:  #ffffff !important; border: none; ">
  <ul class="nav">
    <li class="nav-item">
      <a class="nav-link rounded" href="dashboard.php" style="background-color:#dbdfef;">
        <!-- <i class="typcn typcn-device-desktop menu-icon"></i> -->
        <span class="menu-title">Dashboard</span>
<<<<<<< HEAD
        <div class="badge badge-danger">Reduan</div>
=======
        <div class="badge badge-danger">new</div>
>>>>>>> 379f81f0eff307fcfaa30455d5cd08c2e9c342d1
      </a>
    </li>


    <!-- ================================00 Announsment area ================================== -->
    <li class="nav-item">
      <a class="nav-link" data-toggle="collapse" href="#form-elements" aria-expanded="false" aria-controls="form-elements" style="background:none;">
        <span class="menu-title"> Anounsment</span>

      </a>
      <div class="collapse" id="form-elements">
        <ul class="nav flex-column sub-menu ml-4">
          <li class="nav-item">
            <a class="nav-link" href="slider_area.php">Add Anounsment</a>
          </li>
        </ul>
      </div>
    </li>


     <!-- ================================0 Slider area ================================== -->
     <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#form-elements0" aria-expanded="false" aria-controls="form-elements0" style="background:none;">
          <span class="menu-title">Slider Area</span>
          
        </a>
        <div class="collapse" id="form-elements0">
          <ul class="nav flex-column sub-menu ml-4">
            <li class="nav-item">
              <a class="nav-link" href="slider_area.php">Add Slider</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="slider_area.php">Manage Slider</a>
            </li>
          </ul>
        </div>
      </li>

     <!-- ================================1 Main Notice Area ================================== -->
    <li class="nav-item">
      <a class="nav-link" data-toggle="collapse" href="#form-elements1" aria-expanded="false" aria-controls="form-elements1">
        <span class="menu-title">Main Notice</span>
      </a>
      <div class="collapse" id="form-elements1">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item">
            <a class="nav-link" href="notice_add.php">Add Notice</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="notice_manage.php">Manage Notice</a>
          </li>
        </ul>
      </div>
    </li>


    <!-- ================================2 Latest Notice Area  ================================== -->
    <li class="nav-item">
      <a class="nav-link" data-toggle="collapse" href="#form-elements2" aria-expanded="false" aria-controls="form-elements2">
        <span class="menu-title">Latest Notce</span>
      </a>
      <div class="collapse" id="form-elements2">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item">
            <a class="nav-link" href="latest_notice_add.php">Add Notice</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="latest_notice_manage.php">Manage Notice</a>
          </li>
        </ul>
      </div>
    </li>





  </ul>
</nav>