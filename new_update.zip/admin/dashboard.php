








<?php 
  $view = "dashboard";
  include_once("tamplete.php");

?>