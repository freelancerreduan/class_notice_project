











<?php 
    $view="slider";
    include_once("tamplete.php");
?>