












<?php 
    $view ="latest_notice_add";
    include_once("tamplete.php");
?>