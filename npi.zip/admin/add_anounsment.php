








<?php 
    $view ="add_anounsment";
    include_once("tamplete.php");


?>