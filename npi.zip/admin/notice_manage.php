








<?php 
$view ="notice_manage";
include_once("tamplete.php");

?>