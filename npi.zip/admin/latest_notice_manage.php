













<?php

$view ="latest_notice_manage";
include_once("tamplete.php");


?>