








<?php 
    $view ="notice_add";
    include_once("tamplete.php");


?>