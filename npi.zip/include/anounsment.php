









<div class="d-flex py-2" style="width:100%; background-color:rgba(240, 218, 229, 0.35); border-radius: 7px;">
    <img src="https://metaforce24.com/assets/user/images/aa_new_lv.png" alt="" style="width:30px;height:30px">
    <marquee class="text-white">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit, id natus. Quibusdam delectus error velit quod placeat corrupti aspernatur sunt, eveniet rerum ducimus at ullam officia nobis, dolorum et! Voluptate?</marquee>
</div>